package nl.repsak.backend.dto;

public class CategoryDTO {
    public String nameDutch;
    public String nameEnglish;
}