package nl.repsak.backend.dto;

public class OrderItemDTO {
    public long productId;
    public int quantity;
}
