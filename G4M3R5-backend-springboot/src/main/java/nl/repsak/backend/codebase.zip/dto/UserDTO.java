package nl.repsak.backend.dto;

public class UserDTO {
    public String username;
    public String password;
    public String email;
    public boolean internationalUser;
}
