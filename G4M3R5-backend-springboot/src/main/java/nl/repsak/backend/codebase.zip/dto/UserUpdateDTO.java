package nl.repsak.backend.dto;

public class UserUpdateDTO {
    public String username;
    public String email;
    public boolean isInternational;
}
